package in.app.doctorAppointmentSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;
import java.time.LocalTime;

@SpringBootApplication
public class DoctorAppointmentSystemApplication {

	public static void main(String[] args) {

		SpringApplication.run(DoctorAppointmentSystemApplication.class, args);

	}

}
