package in.app.doctorAppointmentSystem.config;

import in.app.doctorAppointmentSystem.services.UserDetailsServiceImpl;
import in.app.doctorAppointmentSystem.utils.JwtAuthFilter;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.security.Security;

@Configuration
@EnableMethodSecurity
public class SecurityConfiguration {
    @Autowired
    private JwtAuthFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain getSecurityFilterChain(HttpSecurity http){
        return http
                .csrf((csrf)->csrf.disable())
                .authorizeHttpRequests(
                        (auth)->{
                            auth.requestMatchers("/api/doctor_appointment_system/patient/**").permitAll();
                            auth.requestMatchers("/api/doctor_appointment_system/doctor/**").permitAll();
                            auth.requestMatchers("/api/doctor_appointment_system/login").permitAll();
                            auth.anyRequest().authenticated();
                        }
                )
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public PasswordEncoder getPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider getAuthenticationProvider(UserDetailsServiceImpl userDetailsService,PasswordEncoder passwordEncoder){
        DaoAuthenticationProvider provider=new DaoAuthenticationProvider(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder);
        return provider;
    }
}
